//import React from "react";
import Layout from "../components/Layout";

const Help = () => (
  <Layout>
    <div className="dashboard">
      {/* <h1>Suporte</h1> */}
      <p>Funcionalidades para suporte e acionamento do time de auxílio estarão disponíveis aqui!</p>
    </div>
  </Layout>
);

export default Help;
