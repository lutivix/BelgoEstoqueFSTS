//import React from "react";
import Layout from "../components/Layout";

const Settings = () => (
  <Layout>
    <div className="dashboard">
      {/* <h1>Configurações</h1> */}
      <p>Funcionalidade em desenvolvimento...</p>
    </div>
  </Layout>
);

export default Settings;
